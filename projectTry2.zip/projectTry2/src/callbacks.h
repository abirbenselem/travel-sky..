#include <gtk/gtk.h>




void
on_afficherav_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_ajouterav_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retourlv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourll_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouteral_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficheral_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_supprimerlv_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerll_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modifierlv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierll_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
