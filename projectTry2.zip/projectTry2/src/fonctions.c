#include <stdio.h>
#include <string.h>
#include "fonctions.h"
#include <gtk/gtk.h>
enum
{
 MARQUE,
 MODELE,
 MATRICULE,
 COULEUR,
 PRIX_PAR_JOUR,
 COLUMNS1
};
enum
{
 CIN,
 NOM,
 PRENOM,
 NUMERO_DE_TELEPHONE,
 MATRICULE_DE_VEHICULE,
 MARQUE1,
 MODELE1,
 DEBUT_DE_LOCATION,
 FIN_DE_LOCATION,
 COLUMNS
};

void ajouter_vehicule(vehicule v)
{
  FILE *f;
  f=fopen("ajout_vQ","ab+");
  if (!f) g_print("error  !!! ");

  fwrite(&v,sizeof(vehicule),1,f);
  fclose(f);

}
void afficher_vehicule (GtkWidget * liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
       char marque[30];
       char modele[30];
       char matricule[30];
       char couleur[30];
       char prix_par_jour[30];
       store=NULL;
  vehicule  v;
           FILE*f;
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",MARQUE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" modele",renderer,"text",MODELE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" matricule",renderer,"text", MATRICULE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" couleur",renderer,"text",COULEUR, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" prix_par_jour",renderer,"text",PRIX_PAR_JOUR, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
      store=gtk_list_store_new(COLUMNS1, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
      f= fopen("ajout_vQ","rb");
    
      
       
                    while(fread(&v,sizeof(vehicule),1,f)==1)
            {
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter, MARQUE, v.marque, MODELE, v.modele, MATRICULE, v.matricule, COULEUR, v.couleur, PRIX_PAR_JOUR, v.prix_par_jour, -1); 
            }
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}




void ajouter_location(location *l)
{
  FILE *f;
f=fopen("ajout_loc0.bin","ab");
 
  
  
  if (!f) g_print("error"); exit(-1);
fwrite(l,sizeof(location),1,f);
  

fclose(f);
}
void afficher_location (GtkWidget * liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
location l;
      
       date debut_location;
       date fin_location;
       store=NULL;
  
           FILE*f;
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" cin",renderer,"text",CIN, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" numero_de_telephone",renderer,"text",NUMERO_DE_TELEPHONE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" matricule_de_vehicule",renderer,"text",MATRICULE_DE_VEHICULE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",MARQUE1, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" modele",renderer,"text",MODELE1, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
        /*  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" debut_de_location",renderer,"text",DEBUT_DE_LOCATION, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" fin_de_location",renderer,"text",FIN_DE_LOCATION, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);*/
      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
      f= fopen("ajout_loc0.bin","rb");
     
     
         // f= fopen("ajout_loc.txt","a+");
                 char debut_location[1024],fin_location[1024];
   //sprintf(debut_location,"%d %d %d",l.debut_location.jour,l.debut_location.mois,l.debut_location.annee);
//sprintf(debut_location,"%d %d %d",l.fin_location.jour,l.fin_location.mois,l.fin_location.annee);
                    while(fread(&l,sizeof(location),1,f) ==1)
            {
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter, CIN, l.cl.cin, NOM, l.cl.nom, PRENOM, l.cl.prenom, NUMERO_DE_TELEPHONE, l.cl.numero, MATRICULE_DE_VEHICULE, l.vh.matricule, MARQUE, l.vh.marque, MODELE, l.vh.modele, -1); 
            }
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}



void dell_vehicule(char *matricule)
{
vehicule v;
FILE *old;
FILE *new=NULL;

new=fopen("vehicule_test.bin","wb");
fclose(new);

old=fopen("vehicule.bin","rb");
new=fopen("vehicule_test.bin","ab");

int i=0;
while(!(feof(old)))
       {i++;
        fread(&v,1,sizeof(vehicule),old);
       }
fclose(old);
old=fopen("vehicule.bin","rb");

int j=0;
while(j<i-1)
      {j++;
       fread(&v,1,sizeof(vehicule),old);

       if(strcmp(v.matricule,matricule))
             {
             fwrite(&v,sizeof(vehicule),1,new);
             }
      }
fclose(new);
fclose(old);
remove("vehicule.bin");
rename("vehicule_test.bin","vehicule.bin");
}

void dell_location(char *cin)
{
location l;
FILE *old;
FILE *new=NULL;

new=fopen("location_test.bin","wb");
fclose(new);

old=fopen("location.bin","rb");
new=fopen("location_test.bin","ab");
vehicule v;
int i=0;
while(!(feof(old)))
       {i++;
        fread(&v,1,sizeof(location),old);
       }
fclose(old);
old=fopen("location.bin","rb");

int j=0;
while(j<i-1)
      {j++;
       fread(&v,1,sizeof(vehicule),old);

       if(strcmp(l.cl.cin,cin))
             {
             fwrite(&v,sizeof(location),1,new);
             }
      }
fclose(new);
fclose(old);
remove("location.bin");
rename("location_test.bin","location.bin");
}




void mod_vehicule(vehicule z,vehicule b)
{
printf("hghbjn");
/*
vehicule a;
FILE *old;
FILE *new=NULL;

new=fopen("ajoutvehicule_test.bin","wb");
fclose(new);
old=fopen("ajoutvehicule.bin","rb");
new=fopen("ajoutvehicule_test.bin","ab");

int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(vehicule),old);
	}
fclose(old);
old=fopen("ajoutvehicule.bin","rb");

int j=0;
while(j<i)
	{j++;
	fread(&a,1,sizeof(vehicule),old);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fwrite(&a,sizeof(vehicule),1,new);
		}
        else  if(strcmp(a.id,z.id)==0)  
                {
                fread(&b,1,sizeof(vehicule),new);
                
                }
               
	}
fclose(new);
fclose(old);
remove("ajoutvehicule.bin");
rename("ajoutvehicule_test.bin","ajoutvehicule.bin");
//return b;



}

void mod_location(location z,location b)
{
location a;
FILE *old;
FILE *new=NULL;

new=fopen("ajoutlocation_test.bin","wb");
fclose(new);

old=fopen("ajoutlocation.bin","rb");
new=fopen("ajoutlocation_test.bin","ab");

int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(location),old);
	}
fclose(old);
old=fopen("ajoutlocation.bin","rb");

int j=0;
while(j<i)
	{j++;
	fread(&a,1,sizeof(location),old);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fwrite(&a,sizeof(location),1,new);
		}
        else  if(strcmp(a.id,z.id)==0)  
                {
                fread(&b,1,sizeof(location),new);
                
                }
               
	}
fclose(new);
fclose(old);
remove("ajoutlocation.bin");
rename("ajoutlocation_test.bin","ajoutlocation.bin");
//return b;*/



}
