#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include "fonctions.h"
#include<string.h>



void
on_afficherav_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *windowav;
GtkWidget *windowlv;
GtkWidget *treeview1;
  windowav=lookup_widget(obj,"windowav");
  gtk_widget_destroy(windowav);
  windowlv=lookup_widget(obj,"windowlv");
  windowlv=create_windowlv();
   gtk_widget_show(windowlv);
treeview1=lookup_widget(windowlv,"treeview1");
afficher_vehicule(treeview1);



}


void
on_ajouterav_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3;
GtkWidget *couleurv;
vehicule v;
input1=lookup_widget(obj,"marquev");
input2=lookup_widget(obj,"modelev");
input3=lookup_widget(obj,"matriculev");
couleurv=lookup_widget(obj,"combobox");
strcpy (v.marque,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.modele,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));

g_print("ajout_vehicule worked");
ajouter_vehicule(v);


}


void
on_retourlv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *windowav,*windowlv ;
windowav= lookup_widget(objet,"windowav");
windowlv= lookup_widget(objet,"windowlv");
gtk_widget_destroy(windowlv);
windowav= create_windowav();
gtk_widget_show(windowav);

}



void
on_retourll_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowal,*windowll ;
windowal= lookup_widget(objet,"windowal");
windowll= lookup_widget(objet,"windowll");
gtk_widget_destroy(windowll);
windowal= create_windowal();
gtk_widget_show(windowal);


}





void
on_ajouteral_clicked                   (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2, *input3, *input4, *input5, *input6, *input7;
//GtkWidget *Jour_d,*Mois_d , *Annee_d, *Jour_f, *Mois_f, *Annee_f;
location l;
 GtkWidget *jourd,*moisd,*anneed,*jourf,*moisf,*anneef; 

GtkWidget *win = lookup_widget(obj,"windowal");
input1=lookup_widget(obj,"cinl");
input2=lookup_widget(obj,"noml");
input3=lookup_widget(obj,"prenoml");
input4=lookup_widget(obj,"numl");

input5=lookup_widget(obj,"matriculel");
input6=lookup_widget(obj,"marquel");
input7=lookup_widget(obj,"modelel");

jourd = lookup_widget(obj,"jourd");
moisd = lookup_widget(obj,"moisd");
anneed = lookup_widget(obj,"anneed");

jourf = lookup_widget(obj,"jourf");
moisf = lookup_widget(obj,"moisf");
anneef = lookup_widget(obj,"anneef");

strcpy (l.cl.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(l.cl.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy (l.cl.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(l.cl.numero,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(l.vh.matricule,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy (l.vh.marque,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(l.vh.modele,gtk_entry_get_text(GTK_ENTRY(input7)));

l.debut_location.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourd));
l.debut_location.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisd));
l.debut_location.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneed));

l.fin_location.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourf));
l.fin_location.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisf));
l.fin_location.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneef));
/*
l.debut_location.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour_d));
l.debut_location.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois_d));
l.debut_location.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee_d));

l.fin_location.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour_f));
l.fin_location.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois_f));
l.fin_location.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee_f));
*/
g_print("ajout_location worked");
//g_print("%d %d",l.debut_location.jour,l.debut_location.mois);
ajouter_location(&l);

}


void
on_afficheral_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data)
{
//GtkWidget *windowal;
GtkWidget *windowll;
GtkWidget *treeview2;
 // windowal=lookup_widget(obj,"windowal");
  
  windowll=lookup_widget(obj,"windowll");
  windowll=create_windowll();
   gtk_widget_show(windowll);
treeview2=lookup_widget(windowll,"treeview2");
afficher_location(treeview2);
//gtk_widget_destroy(windowal);

}


void
on_supprimerlv_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
/*
vehicule v;
GtkWidget *treeview1;
supprimer1(v.matricule);
/                      




GtkWidget *windowlv=lookup_widget(GTK_WIDGET(button),"windowlv");
treeview1=lookup_widget(windowlv,"treeview1");

afficher_vehicule(treeview1);
gtk_widget_show(treeview1);*/
printf("rftgyhuj");

}

void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeModel *model;
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(GTK_TREE_VIEW(view));
vehicule v;

GtkTreeIter iter;
g_print("This car has been deleted");
list_store=gtk_tree_view_get_model(view);
/*
*/
//if (!gtk_tree_model_get_iter(model,&iter,path))
//g_print("no deleted");
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter,path))
  {
    gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data, -1);


     
  }
strcpy(v.matricule,str_data);
//gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//*



}



void
on_supprimerll_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)

{
location l;
GtkWidget *treeview2;
//supprimer1(l.cl.cin);
//GtkListStore *list_store;/                      
//GtkWidget *treeview2;/


//supprimer(l.cl.cin);
GtkWidget *windowll=lookup_widget(GTK_WIDGET(button),"windowll");
treeview2=lookup_widget(windowll,"treeview2");
//
afficher_location(treeview2);
gtk_widget_show(treeview2);
}




void
on_treeview2_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
location l;
GtkTreeModel *model;
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(GTK_TREE_VIEW(view));


GtkTreeIter iter;
g_print("This renting has been deleted");
list_store=gtk_tree_view_get_model(view);
/*
*/
//if (!gtk_tree_model_get_iter(model,&iter,path))
//g_print("no deleted");
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter,path))
  {
    gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data, -1);


     
  }
strcpy(l.cl.cin,str_data);
//gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//*



}




void
on_modifierlv_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
/*
vehicule v;
GtkWidget *matricule,*marque,*modele,*couleur,*prix_par_jour;
dell_user(v.matricule);

GtkWidget *windowlv=lookup_widget(button,"windowlv");
GtkWidget *windowav=lookup_widget(button,"windowav");
gtk_widget_hide(windowlv);
windowav=create_windowav();
gtk_widget_show(windowav);

matricule=lookup_widget(windowav,"matricule");
gtk_entry_set_text(GTK_ENTRY(matricule),v.matricule);

marque=lookup_widget(windowav,"marque");
gtk_entry_set_text(GTK_ENTRY(marque),v.marque);

modele=lookup_widget(windowav,"modele");
gtk_entry_set_text(GTK_ENTRY(modele),v.modele);

couleur=lookup_widget(windowav,"couleur");
gtk_entry_set_text(GTK_ENTRY(couleur),v.couleur);

prix_par_jour=lookup_widget(windowav,"prix_par_jour");
gtk_entry_set_text(GTK_ENTRY(prix_par_jour),v.prix_par_jour);

}


void
on_modifierll_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
location l;
GtkWidget *cin, *nom, *prenom, *numero_de_telephone, *matricule, *marque, *modele, *debut_de_location, *fin_de_location;
dell_location(l.cl.cin);

GtkWidget *windowll=lookup_widget(button,"windowll");
GtkWidget *windowal=lookup_widget(button,"windowal");
gtk_widget_hide(windowll);
windowal=create_windowal();
gtk_widget_show(windowal);

cin=lookup_widget(windowal,"cin");
gtk_entry_set_text(GTK_ENTRY(cin),l.cl.cin);

nom=lookup_widget(windowal,"nom");
gtk_entry_set_text(GTK_ENTRY(nom),l.cl.nom);

prenom=lookup_widget(windowal,"prenom");
gtk_entry_set_text(GTK_ENTRY(prenom),l.cl.prenom);

numero_de_telephone=lookup_widget(windowal,"numero_de_telephone");
gtk_entry_set_text(GTK_ENTRY(numero_de_telephone),l.cl.numero);

matricule=lookup_widget(windowal,"matricule");
gtk_entry_set_text(GTK_ENTRY(matricule),l.vh.matricule);

marque=lookup_widget(windowal,"marque");
gtk_entry_set_text(GTK_ENTRY(marque),l.vh.marque);

modele=lookup_widget(windowal,"modele");
gtk_entry_set_text(GTK_ENTRY(modele),l.vh.modele);
/*
debut_de_location=lookup_widget(windowal,"debut_de_location");
gtk_entry_set_text(GTK_ENTRY(debut_de_location),l.debut_location);*/
/*
fin_de_location=lookup_widget(windowal,"fin_de_location");
gtk_entry_set_text(GTK_ENTRY(fin_de_location),l.fin_location);
*/
}

