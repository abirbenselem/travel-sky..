#include <gtk/gtk.h>

typedef struct date date;
struct date
{
int jour;
int mois;
int annee;
};

typedef struct vehicule vehicule;
struct vehicule
{
char marque[40];
char modele[40];  
char matricule[40];
char couleur[40];
char prix_par_jour[40];
};

typedef struct client client ;
struct client 
{
char cin[40];
char nom[40];
char prenom[40];
char numero[40];
char e_mail[90];
date date_depart;
date date_arrivee;
char destination[40];
};

typedef struct location location ;
struct location
{
client cl;//8
vehicule vh;//5
date debut_location;//3
date fin_location;//3
};


void ajouter_vehicule (vehicule v);
void afficher_vehicule (GtkWidget * liste);
void ajouter_location (location *l);
void afficher_location (GtkWidget * liste);
void dell_location(char *cin);
void dell_vehicule(char *matricule);
void mod_vehicule(vehicule z,vehicule b);
void mod_location(location z,location b);
/*
void modifier_location;
void modifier_vehicule;
*/


