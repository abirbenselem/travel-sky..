#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"excursion.h"

excursion e;








void
on_validjout_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
excursion e;
GtkWidget *jrd=lookup_widget(GTK_WIDGET(button),"jrd");
GtkWidget *msd=lookup_widget(GTK_WIDGET(button),"msd");
GtkWidget *and=lookup_widget(GTK_WIDGET(button),"and");
GtkWidget *jra=lookup_widget(GTK_WIDGET(button),"jra");
GtkWidget *msa=lookup_widget(GTK_WIDGET(button),"msa");
GtkWidget *ana=lookup_widget(GTK_WIDGET(button),"ana");
GtkWidget *classe=lookup_widget(GTK_WIDGET(button),"classe");
GtkWidget *tarif=lookup_widget(GTK_WIDGET(button),"tarif");
GtkWidget *arrivee=lookup_widget(GTK_WIDGET(button),"arrivee");
GtkWidget *depart=lookup_widget(GTK_WIDGET(button),"depart");
GtkWidget *heure=lookup_widget(GTK_WIDGET(button),"heure");
strcpy(e.depart,gtk_entry_get_text(GTK_ENTRY(depart)));
strcpy(e.arrivee,gtk_entry_get_text(GTK_ENTRY(arrivee)));
e.aller.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrd));
e.aller.mois=(int) gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(msd));
e.aller.annee=(int) gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(and));

e.retour.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jra));
e.retour.mois=(int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(msa));
e.retour.annee=(int) gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ana));
strcpy(e.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));
strcpy(e.tarif,gtk_entry_get_text(GTK_ENTRY(tarif)));
strcpy(e.heure,gtk_entry_get_text(GTK_ENTRY(heure)));



ajouter(&e);
}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
excursion e;
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");

GtkWidget *treeview1;
gtk_widget_destroy(window1);
window2=create_window2();
gtk_widget_show(window2);

treeview1=lookup_widget(window2,"treeview1");
afficher (treeview1,e);
}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)e.tarif);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *treeview1;

treeview1=lookup_widget(window2,"treeview1");

afficher(treeview1,e);
gtk_widget_show(treeview1);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data, -1);
  }
strcpy(e.tarif,str_data);

}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GTKWidget *fen_log,fen2 ;
fen_log = lookup_widget(button,"window1");
fen2= lokkup_widget(button,"window2");
gtk_widget_destroy(fen2);
fen_log = create_window1();
gtk_widget_show(fen_log);

}


void
on_save_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

