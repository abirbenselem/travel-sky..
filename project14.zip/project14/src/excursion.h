#ifndef EXCURSION_H_
#define EXCURSION_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_excursion
{
int jour;
int mois;
int annee;
}date;

typedef struct
{ 
date aller;
date retour;
char depart[20];
char arrivee[20];
char classe[100];
char heure[20];
char tarif[20];
}excursion;

void ajouter (excursion *e); 
void afficher (GtkWidget *liste,excursion e);
void dell_user(char *tarif);
#endif
