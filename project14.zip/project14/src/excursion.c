#include "excursion.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 DEPART,
 ARRIVEE,
 DATEA,
 DATER,
 CLASSE,
 HEURE,
 TARIF,
 COLUMNS
};
void ajouter (excursion *e)
{
FILE *f;
f=fopen("excursion.bin","ab"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(e,sizeof(excursion),1,f);
fclose(f); } //fermeture du fichier
}

void afficher (GtkWidget *liste,excursion e)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Depart ", renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Arrivee ", renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date d'aller", renderer,"text",DATEA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Date de retour", renderer,"text",DATER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" classe", renderer,"text",CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("heure", renderer,"text",HEURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("tarif", renderer,"text",TARIF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("excursion.bin","rb"); 
if(f!=NULL) 
{
while (!(feof(f)))
{
fread (&e, sizeof(excursion),1,f);

char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_aller[20]="";
char dt_retour[20]="";

sprintf(r1,"%d",e.aller.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",e.aller.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",e.aller.annee);
strcat(dt_aller,r3);

sprintf(r4,"%d",e.retour.jour);
strcat(dt_retour,r4);
strcat(dt_retour,"/");
sprintf(r5,"%d",e.retour.mois);
strcat(dt_retour,r5);
strcat(dt_retour,"/");
sprintf(r6,"%d",e.retour.annee);
strcat(dt_retour,r6);

gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART,e.depart,ARRIVEE,e.arrivee,DATEA,dt_aller,DATER,dt_retour,CLASSE,e.classe,HEURE,e.heure,TARIF,e.tarif, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
/*********Supp User***************/
void dell_user(char *tarif)
{
excursion e;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("excursion_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("excursion.bin","rb");
new=fopen("excursion_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&e,1,sizeof(excursion),old);
	}
fclose(old);
old=fopen("excursion.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&e,1,sizeof(excursion),old);
	
	if(strcmp(e.tarif,tarif))
		{	
		fwrite(&e,sizeof(excursion),1,new);
		}
	}
fclose(new);
fclose(old);
remove("excursion.bin");//nfas5ou il fichier li9dim
rename("excursion_test.bin","excursion.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}
