#ifndef CLIENT_H_
#define CLIENT_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct 
{
     char nom[30];
     char prenom[30];
     char cin[30];
     char numpasseport[30];
     char passwd[30];
     char numtel[30];
     char login[30];
     char email[30];

     


} client;
void ajoutclient (client *c);
void affichclient (GtkWidget *liste,client c);

void dell_client(char *cin);
void mod_client(char *cin);

#endif
