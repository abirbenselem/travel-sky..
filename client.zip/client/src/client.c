#include "client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 CIN,
 NOM,
 PRENOM,
 NUMTEL,
 NUMPASSEPORT,
 EMAIL,
 LOGIN,
 PASSWD,
 COLUMNS
};
client c ;
void ajoutclient (client *c1)
{
FILE *f;
f=fopen("ajout_client","ab+"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(c1,sizeof(client),1,f);
fclose(f); } //fermeture du fichier
}
void affichclient (GtkWidget *liste,client client_)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter miter;
GtkListStore *store;
store=NULL;
//FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" cin ", renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" nom ", renderer,"text" ,NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" prenom", renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("numtel", renderer,"text",NUMTEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" numpasseport", renderer,"text",NUMPASSEPORT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("email", renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("login", renderer,"text",LOGIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("passwd", renderer,"text",PASSWD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
}
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


      FILE *f = fopen("ajout_client","rb") ;
      if(!f) exit(-1);

      while(fread(&client_,sizeof(client),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          
          gtk_list_store_set(store,&miter,CIN,client_.cin,NOM,client_.nom,PRENOM,client_.prenom,NUMTEL,client_.numtel,NUMPASSEPORT,
client_.numpasseport,EMAIL,client_.email,LOGIN,client_.login,PASSWD,client_.passwd,-1);


      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
      g_object_unref(store);





}
void dell_client(char *cin)
{
client c2;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("ajout_client_test","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajout_client","rb");
new=fopen("ajout_client_test","ab+");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&c2,1,sizeof(client),old);
	}
fclose(old);
old=fopen("ajout_client","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&c2,1,sizeof(client),old);
	
	if(strcmp(c2.cin,cin))
		{	
		fwrite(&c2,sizeof(client),1,new);
		}
	}
fclose(new);
fclose(old);
remove("ajout_client");
rename("ajout_client_test","ajout_client");


}
void mod_client(char *cin)
{
client a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("ajout_client","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajout_client","rb");
new=fopen("ajout_client_test","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(client),old);
	}
fclose(old);
old=fopen("ajout_client","rb");
/******************************/
int j=0;
while(j<i)
	{j++;
	fread(&a,1,sizeof(client),old);
	
	if(strcmp(a.cin,cin)!=0)
		{	
		fwrite(&a,sizeof(client),1,new);
		}
        else  if(strcmp(a.cin,cin)==0)  
                {
                fread(&a,sizeof(client),1,new);
                
                }
               
	}
fclose(new);
fclose(old);
remove("ajout_client");//nfas5ou il fichier li9dim
rename("ajout_client_test","ajout_client");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
//return b;

/*****Na3mlo Actualiser lil liste **************/

}




