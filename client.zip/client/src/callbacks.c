#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"client.h"


 
void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *msge;

client c;
GtkWidget *cin=lookup_widget(GTK_WIDGET(button),"cin");
GtkWidget *nom=lookup_widget(GTK_WIDGET(button),"nom");
GtkWidget *prenom=lookup_widget(GTK_WIDGET(button),"prenom");
GtkWidget *numtel=lookup_widget(GTK_WIDGET(button),"numtel");
GtkWidget *numpasseport=lookup_widget(GTK_WIDGET(button),"numpasseport");
GtkWidget *login=lookup_widget(GTK_WIDGET(button),"login");
GtkWidget *passwd=lookup_widget(GTK_WIDGET(button),"passwd");
GtkWidget *email=lookup_widget(GTK_WIDGET(button),"email");
msge=lookup_widget(GTK_LABEL(button),"msg");
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(c.numtel,gtk_entry_get_text(GTK_ENTRY(numtel)));
strcpy(c.numpasseport,gtk_entry_get_text(GTK_ENTRY(numpasseport)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(c.passwd,gtk_entry_get_text(GTK_ENTRY(passwd)));



ajoutclient(&c);
gtk_label_set_text(GTK_LABEL(msge),"ajouté avec succés");

}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ 
client c;
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");

GtkWidget *treeview1;
gtk_widget_destroy(window1);
window2=create_window2();
gtk_widget_show(window2);

treeview1=lookup_widget(window2,"treeview1");
affichclient (treeview1,c);
}
client c2;

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_client(c2.cin);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *treeview1;

treeview1=lookup_widget(window2,"treeview1");

affichclient(treeview1,c2);
gtk_widget_show(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

gchar *str_data ,*str_data1,*str_data2,*str_data3,*str_data4,*str_data5,*str_data6,*str_data7;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data2, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data3, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data4, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data5, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data6, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 7, &str_data7, -1);
  }
strcpy(c2.cin,str_data);
strcpy(c2.nom,str_data1);
strcpy(c2.prenom,str_data2);
strcpy(c2.numtel,str_data3);
strcpy(c2.numpasseport,str_data4);
strcpy(c2.email,str_data5);
strcpy(c2.login,str_data6);
strcpy(c2.passwd,str_data7);
}


void
on_ajouterclient_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fen1,*fen22 ;
fen1 = lookup_widget(GTK_WIDGET(button),"window1");
fen22= lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_destroy(fen22);
fen1 = create_window1();
gtk_widget_show(fen1);
}


void
on_save_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

/**GtkWidget *cin,*nom,*prenom,*numtel,*numpasseport,*email,*login,*passwd;**/
mod_client(c2.cin);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window2=lookup_widget(button,"window2");
GtkWidget *window1=lookup_widget(button,"window1");
gtk_widget_destroy(window2);
window1=create_window1();
gtk_widget_show(window1);

GtkWidget *cin=lookup_widget(window1,"cin");
gtk_entry_set_text(GTK_LABEL(cin),c2.cin);

GtkWidget *nom=lookup_widget(window1,"nom");
gtk_entry_set_text(GTK_LABEL(nom),c2.nom);

GtkWidget *prenom=lookup_widget(window1,"prenom");
gtk_entry_set_text(GTK_LABEL(prenom),c2.prenom);

GtkWidget *numtel=lookup_widget(window1,"numtel");
gtk_entry_set_text(GTK_LABEL(numtel),c2.numtel);

GtkWidget *numpasseport=lookup_widget(window1,"numpasseport");
gtk_entry_set_text(GTK_LABEL(numpasseport),c2.numpasseport);

GtkWidget *email=lookup_widget(window1,"email");
gtk_entry_set_text(GTK_LABEL(email),c2.email);

GtkWidget *login=lookup_widget(window1,"login");
gtk_entry_set_text(GTK_LABEL(login),c2.login);

GtkWidget *passwd=lookup_widget(window1,"passwd");
gtk_entry_set_text(GTK_LABEL(passwd),c2.passwd);
}

