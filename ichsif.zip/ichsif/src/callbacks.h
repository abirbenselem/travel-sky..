#include <gtk/gtk.h>
#include "add.h"

void
on_ajouter_clicked                     (GtkWidget       *Objet,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Voitures_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Gerer_les_factures_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Add_facture_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);
void
on_add_fact_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_valid_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Voit_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);



void
on_ajout_fact_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);



void
on_button10_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_mod_clicked                         (GtkButton       *button,
                                        gpointer         user_data);
