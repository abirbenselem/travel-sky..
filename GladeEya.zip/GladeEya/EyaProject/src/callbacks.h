#include <gtk/gtk.h>


void
on_catalogue_cons_clicked              (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back1_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_quit2_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_offre_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_billet_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_vorganis_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_reserver_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annule_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back4_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_quit6_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Login_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_signup_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);



void
on_buttonModif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_AddBillo_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_EyaShow1_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
