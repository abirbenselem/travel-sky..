
#include<gtk/gtk.h>
typedef struct Voyage_Organise Voyage_Organise;

struct Voyage_Organise
{
char dest[30];
char Duree[30];
char tar_[30];
char desc[30];

};

void Voyage_org(Voyage_Organise *vo);


