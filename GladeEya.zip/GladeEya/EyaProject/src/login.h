
#include<gtk/gtk.h>

typedef struct  Login Login;


struct Login
{

char user[30];
 char cin[30];
char passwd[30];
char log_[30];
char email[30];
char tel[30];

};

void Ajout_client(Login * log);

