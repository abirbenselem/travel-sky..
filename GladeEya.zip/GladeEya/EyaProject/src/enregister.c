
#include<string.h>
#include<stdlib.h>
#include"enregister.h"
#include<stdio.h>

void enrg_billets(Billets *biilets)
{
FILE *f = fopen("Billets","ab+");
   if(!f) g_print("error ");

   fwrite(biilets,sizeof(Billets),1,f);

  fclose(f);
}
enum
{
 DEPART,
 ARRIVE,

 CLASSE,

 COLUMNS
};

void supprimer(char *)
{

}

void afficher_hotels (GtkWidget* liste){
    Billets h;
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter miter;
      GtkListStore *store ;
     
      char nom_hotel[20];
      char adresse[20];
      char etoile[10];
      char num_responsable[20];
    store = NULL;
     
      //FILE *f ;
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
      if(!store){
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("depart",render,"text",DEPART,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("arrive",render,"text",ARRIVE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          /* render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("depart",render,"text",DEPART,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);*/

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("classe",render,"text",CLASSE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
          
          
      }

      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


      FILE *f = fopen("Billets","rb") ;
      if(!f) exit(-1);

      while(fread(&h,sizeof(Billets),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          
          gtk_list_store_set(store,&miter,DEPART,h.Depart,ARRIVE,h.Arrive,CLASSE,h.classe);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
      g_object_unref(store);
}


