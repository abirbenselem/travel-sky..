#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "enregister.h"
#include "voyorganise.h"
#include "login.h"
#include<string.h>






void
on_catalogue_cons_clicked              (GtkWidget      *obj,
                                        gpointer         user_data)
{
on_EyaShow1_clicked(obj,user_data);

/*
     GtkWidget *open_fen , *kill_fen ;
     
    kill_fen = lookup_widget(obj,"window8");
      kill_fen = create_window8();
     //gtk_widget_hide(kill_fen);
open_fen = lookup_widget(kill_fen,"treeview1");
     gtk_widget_show(kill_fen);*/
}

void
on_button2_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data)
{

  exit(-1);
}

void
on_back1_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{

    GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"client");
    kill_fen = lookup_widget(obj,"window2");
      open_fen = create_window6();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
}

void
on_quit2_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{

  exit(-1);
}

void
on_offre_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{
g_print("offre");
}

void
on_billet_clicked                      (GtkWidget       *obj,
                                        gpointer         user_data)
{
g_print("billet_clicked");

 GtkWidget *open_fen , *kill_fen,*winds1,*winf2 ;
     open_fen = lookup_widget(obj,"window4");
    kill_fen = lookup_widget(obj,"window5");
   winds1 = lookup_widget(obj,"window3");
    winf2 = lookup_widget(obj,"window2");
      winds1 = create_window3();
      winf2 = create_window2();
      open_fen = create_window4();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
     // gtk_widget_show(winds1);
 //gtk_widget_show(winf2);
}

void
on_vorganis_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{

   GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
input1 = lookup_widget(obj,"userS");
input2 = lookup_widget(obj,"email");
input3 = lookup_widget(obj,"entryCin");
input4 = lookup_widget(obj,"eLogin");
input5 = lookup_widget(obj,"entrypasswd");
input6 = lookup_widget(obj,"entry14");
Login logh ;
strcpy(logh.user, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(logh.cin, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(logh.passwd, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(logh.log_, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(logh.email, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(logh.tel, gtk_entry_get_text(GTK_ENTRY(input6)));
Ajout_client(&logh);
 GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"window5");
    kill_fen = lookup_widget(obj,"window6");
      open_fen = create_window5();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
}

void
on_reserver_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data){


 
   GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
input1 = lookup_widget(obj,"userS");
input2 = lookup_widget(obj,"email");
input3 = lookup_widget(obj,"entryCin");
input4 = lookup_widget(obj,"eLogin");
input5 = lookup_widget(obj,"entrypasswd");
input6 = lookup_widget(obj,"entry14");
Login logh ;
strcpy(logh.user, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(logh.cin, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(logh.passwd, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(logh.log_, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(logh.email, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(logh.tel, gtk_entry_get_text(GTK_ENTRY(input6)));
Ajout_client(&logh);
 GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"window5");
    kill_fen = lookup_widget(obj,"window6");
      open_fen = create_window5();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
}

void
on_annule_clicked                      (GtkWidget       *obj,
                                        gpointer         user_data)
{
   g_print("annuler");

}

void
on_back4_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{
  GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"window3");
    kill_fen = lookup_widget(obj,"window4");
      open_fen = create_window6();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
}







void
on_quit6_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{
   exit(-1);
}


void
on_Login_clicked                       (GtkWidget       *obj,
                                        gpointer         user_data)
{
      GtkWidget *open_fen , *kill_fen,*winds1,*winf2 ;
     open_fen = lookup_widget(obj,"window4");
    kill_fen = lookup_widget(obj,"window5");
   winds1 = lookup_widget(obj,"window3");
    winf2 = lookup_widget(obj,"window2");
      winds1 = create_window3();
      winf2 = create_window2();
      open_fen = create_window4();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);
      gtk_widget_show(winds1);
 gtk_widget_show(winf2);
}


void
on_signup_clicked                      (GtkWidget       *obj,
                                        gpointer         user_data)
{
     GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"window6");
    kill_fen = lookup_widget(obj,"window5");
      open_fen = create_window6();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);


  

      
}


void
on_save_clicked                        (GtkWidget       *obj,
                                        gpointer         user_data)
{

    GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
input1 = lookup_widget(obj,"userS");
input2 = lookup_widget(obj,"email");
input3 = lookup_widget(obj,"entryCin");
input4 = lookup_widget(obj,"eLogin");
input5 = lookup_widget(obj,"entrypasswd");
input6 = lookup_widget(obj,"entry14");
Login logh ;
strcpy(logh.user, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(logh.cin, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(logh.passwd, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(logh.log_, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(logh.email, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(logh.tel, gtk_entry_get_text(GTK_ENTRY(input6)));
Ajout_client(&logh);
 GtkWidget *open_fen , *kill_fen ;
     open_fen = lookup_widget(obj,"window5");
    kill_fen = lookup_widget(obj,"window6");
      open_fen = create_window5();
     gtk_widget_hide(kill_fen);
     gtk_widget_show(open_fen);




    
}


void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_dt;
GtkTreeModel *model;
GtkTreeIter iter;
g_print("dbl clicked to deleted");
model= gtk_tree_view_get_model(view);
if(!gtk_tree_model_get_iter(model,&iter,path))
   g_print("no deleed");
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
}


void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
   GtkWidget *win2= lookup_widget(button,"window8");
   win2 = create_window8();

    GtkWidget *treeview1;
 treeview1=lookup_widget(win2,"treeview1");
  afficher_hotels(treeview1);
gtk_widget_show(treeview1);


 
   

  
   
}





void
on_buttonModif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AddBillo_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
Billets d;
GtkWidget *inp1, *inp2,*inp3,*inp4 ;
GtkWidget *j1, *m1 , *a1 , *j2,*m2,*a2;
inp1 =lookup_widget(obj,"entry5");
inp2 =lookup_widget(obj,"entry6");
j1 =lookup_widget(obj,"spinbutton1");
m1 =lookup_widget(obj,"spinbutton2");
a1 =lookup_widget(obj,"spinbutton3");
j2 =lookup_widget(obj,"spinbutton4");
m2 =lookup_widget(obj,"spinbutton5");
a2 =lookup_widget(obj,"spinbutton6");
inp3 =lookup_widget(obj,"combobox2");
inp4 =lookup_widget(obj,"client");
strcpy(d.Depart,gtk_entry_get_text(GTK_ENTRY(inp1)));
strcpy(d.Arrive,gtk_entry_get_text(GTK_ENTRY(inp2)));

//strcpy(b.Depart,gtk_entry_get_text(GTK_ENTRY(inp1)));

d.dep.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j1));

d.dep.m= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m1));
d.dep.y =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a1));

d.dep.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j2));

d.dep.m= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m2));
d.dep.y =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a2));


strcpy(d.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(inp3)));


inp4=create_client();

gtk_widget_show(inp4);
g_print("sade create file succus");
enrg_billets(&d);



 









}


void
on_EyaShow1_clicked                    (GtkWidget      *obj,
                                        gpointer         user_data)
{
   
GtkWidget *win , *kil ;
GtkWidget *treeviews;

win =  lookup_widget(obj,"window8");
win =create_window8();
treeviews = lookup_widget(win,"treeview1");

gtk_widget_show(win);
afficher_hotels(treeviews);














}


