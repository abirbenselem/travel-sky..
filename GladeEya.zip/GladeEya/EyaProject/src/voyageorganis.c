
#include<gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "voyorganise.h"
void Voyage_org(Voyage_Organise *Vo)
{

FILE *f = fopen("Voyorg","ab+");
   if(!f) g_print("error ");

   fwrite(Vo,sizeof(Voyage_Organise),1,f);

  fclose(f);
}


