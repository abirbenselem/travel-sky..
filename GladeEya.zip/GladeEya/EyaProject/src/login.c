#include "login.h"
#include<gtk/gtk.h>
#include<stdlib.h>
#include<string.h>
void Ajout_client(Login * log)
{
   FILE *f = fopen("clients","ab+");
   if(!f) g_print("error ");

   fwrite(log,sizeof(Login),1,f);

  fclose(f);
}

