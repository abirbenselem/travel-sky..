
#include<gtk/gtk.h>

typedef struct Date Date;
struct Date
{  
   int j , m ,y;

};

typedef struct Billets Billets;
struct Billets
{
char Depart[30];
 char Arrive[30];
Date dep ,  arr;
char classe[40];
 

};

void afficher_hotels (GtkWidget* liste);

void supprimer1(char *);
